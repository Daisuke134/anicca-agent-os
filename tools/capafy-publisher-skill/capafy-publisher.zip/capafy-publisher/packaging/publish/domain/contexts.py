from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional, Set

from packaging.runtime.contracts import DeepScanFindingsInput
from packaging.runtime.stage_plan import StagePlan


@dataclass(frozen=True)
class StageContext:
    staging_root: Path
    stage_plan: StagePlan
    bundle_context: Dict[str, Any]
    selected_skill_paths: Optional[Set[str]]
    target: Any
    workspace_documents_manifest_payload: Optional[Dict[str, Any]] = None
    workspace_allowlist: Optional[Set[str]] = None


@dataclass(frozen=True)
class PrepareContext:
    agent_id: str
    latest_state: Any
    manifest: Any
    deep_scan: bool = False
    overrides: Optional[Dict[str, str]] = None
    deep_scan_findings: DeepScanFindingsInput = field(default_factory=DeepScanFindingsInput)
    environment_selection_file: Optional[str] = None
