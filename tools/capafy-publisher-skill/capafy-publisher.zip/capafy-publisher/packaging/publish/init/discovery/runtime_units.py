from __future__ import annotations

import os
from pathlib import Path, PurePosixPath

from packaging.common.fs import (
    display_stage_path,
    looks_like_absolute_symlink,
    looks_like_virtualenv_dir,
    relpath as fs_relpath,
)
from packaging.common.packaged_files import should_skip_packaged_relpath
from packaging.publish.selection.units import (
    classify_selectable_directory,
    finalize_selectable_entry,
)
from packaging.publish.selection.unit_metadata import build_unit_metadata
from packaging.publish.selection.path_shapes import basic_allowed_skill_root_prefixes
from packaging.runtime.stage_plan import StagePlan, StageTreeSource


def _skill_root_prefix(path: object) -> str:
    normalized = PurePosixPath(str(path or "").strip().rstrip("/")).as_posix()
    if not normalized or normalized == ".":
        return ""
    parts = [part for part in PurePosixPath(normalized).parts if part and part != "."]
    for index, part in enumerate(parts):
        if part == "skills":
            return PurePosixPath(*parts[: index + 1]).as_posix()
    return ""


def _build_discovered_entry(
    unit_path: Path,
    display_path: str,
    source_root_display: str,
    *,
    discovery_root: str,
    unit_type: str,
    target=None,
) -> dict:
    meta = build_unit_metadata(unit_path, unit_type, target=target)
    entry = {
        "path": display_path,
        "name": meta["name"],
        "description": meta["description"],
        "source_root": source_root_display,
        "discovery_root": discovery_root,
        "unit_type": unit_type,
        "has_primary_doc": meta["has_primary_doc"],
        "synopsis": meta["synopsis"],
        "suspicious_reasons": meta["suspicious_reasons"],
    }
    if unit_type == "skill":
        entry["source_path"] = str(unit_path.expanduser().resolve(strict=False))
        entry["binding_kind"] = "workspace_skill_dir"
    return finalize_selectable_entry(target, entry, unit_path=unit_path)


def _discovery_root_for_tree_source(tree_source: StageTreeSource) -> str:
    raw = str(getattr(tree_source, "source_key", "")).strip().rstrip("/")
    if raw:
        normalized = PurePosixPath(raw).as_posix()
        return "" if normalized == "." else normalized
    return ""


def _append_discovered_entry(
    discovered: list[dict],
    seen: set[tuple[str, str]],
    *,
    unit_path: Path,
    display_path: str,
    display_prefix: str,
    discovery_root: str,
    unit_type: str,
    target=None,
) -> None:
    dedupe_key = (display_path, discovery_root)
    if dedupe_key in seen:
        return
    discovered.append(
        _build_discovered_entry(
            unit_path,
            display_path,
            display_prefix,
            discovery_root=discovery_root,
            unit_type=unit_type,
            target=target,
        )
    )
    seen.add(dedupe_key)


def _iter_tree_source_units(
    tree_source: StageTreeSource,
    *,
    target=None,
) -> list[dict]:
    source_root = tree_source.source_root.expanduser()
    if not source_root.is_dir():
        return []

    display_prefix = str(tree_source.display_prefix).strip().rstrip("/")
    allowed_skill_roots = basic_allowed_skill_root_prefixes(display_prefix)
    discovery_root = _discovery_root_for_tree_source(tree_source)
    discovered: list[dict] = []
    seen: set[tuple[str, str]] = set()

    for current, dirnames, filenames in os.walk(source_root, topdown=True):
        current_path = Path(current)
        current_relpath = fs_relpath(current_path, source_root)
        kept_dirs: list[str] = []

        for dirname in sorted(dirnames):
            candidate_path = current_path / dirname
            relpath = display_stage_path(current_relpath, dirname)
            display_path = display_stage_path(display_prefix, relpath)
            skill_root_path = _skill_root_prefix(display_path)

            selectable_path, unit_type, keep_descending = classify_selectable_directory(
                target,
                candidate_path,
                display_path,
            )

            if looks_like_virtualenv_dir(candidate_path):
                continue

            if looks_like_absolute_symlink(candidate_path):

                if selectable_path == display_path and unit_type != "suppressed" and candidate_path.exists():
                    _append_discovered_entry(
                        discovered,
                        seen,
                        unit_path=candidate_path,
                        display_path=display_path,
                        display_prefix=display_prefix,
                        discovery_root=discovery_root,
                        unit_type=unit_type,
                        target=target,
                    )
                continue

            if should_skip_packaged_relpath(
                relpath,
                is_dir=True,
            ):
                continue

            if allowed_skill_roots and skill_root_path and skill_root_path not in allowed_skill_roots:
                continue

            if selectable_path == display_path and unit_type != "suppressed":
                _append_discovered_entry(
                    discovered,
                    seen,
                    unit_path=candidate_path,
                    display_path=display_path,
                    display_prefix=display_prefix,
                    discovery_root=discovery_root,
                    unit_type=unit_type,
                    target=target,
                )

                if keep_descending:
                    kept_dirs.append(dirname)
                continue

            if keep_descending:
                kept_dirs.append(dirname)

        dirnames[:] = kept_dirs

    return discovered


def discover_units(
    stage_plan: StagePlan,
    *,
    target=None,
) -> tuple[list[dict], list[dict]]:
    discovered: list[dict] = []
    suspicious: list[dict] = []
    seen_units: set[tuple[str, str]] = set()

    for tree_source in stage_plan.tree_sources:
        for entry in _iter_tree_source_units(tree_source, target=target):
            path = str(entry.get("path", "")).strip()
            discovery_root = str(entry.get("discovery_root", "")).strip()
            dedupe_key = (path, discovery_root)
            if not path or dedupe_key in seen_units:
                continue
            seen_units.add(dedupe_key)
            discovered.append(entry)
            if entry.get("suspicious_reasons"):
                suspicious.append(entry)

    discovered.sort(key=lambda item: (str(item.get("path", "")), str(item.get("discovery_root", ""))))
    suspicious.sort(key=lambda item: (str(item.get("path", "")), str(item.get("discovery_root", ""))))
    return discovered, suspicious


__all__ = [
    "discover_units",
]
