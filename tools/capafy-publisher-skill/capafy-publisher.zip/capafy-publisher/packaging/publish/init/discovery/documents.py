from __future__ import annotations
from typing import Optional, TypedDict

import os
from pathlib import Path

from packaging.common.fs import (
    display_stage_path,
    looks_like_absolute_symlink,
    looks_like_virtualenv_dir,
    read_text,
    relpath as fs_relpath,
)
from packaging.common.packaged_files import should_skip_packaged_relpath
from packaging.common.instruction_docs import is_instruction_doc
from packaging.publish.selection.selectable import should_skip_skill_reference_document
from packaging.runtime.profiles.path_resolver import resolve_path_spec
from packaging.runtime.contracts import call_optional_target_hook
from packaging.publish.selection.units import classify_selectable_directory
from packaging.runtime.stage_plan import StagePlan, StageTreeSource



class SourceDocument(TypedDict):
    path: str
    text: str
    is_instruction: bool
    source_file: str


def _build_document_entry(display_path: str, source_file: Path, text: str) -> SourceDocument:
    return {
        "path": display_path,
        "text": text,
        "is_instruction": is_instruction_doc(display_path),
        "source_file": str(source_file),
    }


def _iter_tree_source_documents(
    tree_source: StageTreeSource,
    *,
    runtime_root: Optional[Path] = None,
    target=None,
) -> list[SourceDocument]:
    source_root = tree_source.source_root.expanduser().resolve(strict=False)
    if not source_root.is_dir():
        return []

    discovered: list[SourceDocument] = []
    seen: set[str] = set()

    for current, dirnames, filenames in os.walk(source_root, topdown=True):
        current_path = Path(current)
        current_relpath = fs_relpath(current_path, source_root)
        if source_root == runtime_root:
            dirnames[:] = []
        else:
            kept_dirs: list[str] = []

            for dirname in sorted(dirnames):
                candidate_path = current_path / dirname
                relpath = display_stage_path(current_relpath, dirname)
                display_path = display_stage_path(tree_source.display_prefix, relpath)
                selectable_path, _unit_type, keep_descending = classify_selectable_directory(
                    target,
                    candidate_path,
                    display_path,
                )


                if looks_like_virtualenv_dir(candidate_path):
                    continue
                if looks_like_absolute_symlink(candidate_path):
                    continue
                if should_skip_packaged_relpath(
                    relpath,
                    is_dir=True,
                ):
                    continue
                if keep_descending:
                    kept_dirs.append(dirname)

            dirnames[:] = kept_dirs

        for filename in sorted(filenames):
            source_file = current_path / filename
            relpath = display_stage_path(current_relpath, filename)
            display_path = display_stage_path(tree_source.display_prefix, relpath)
            if source_root == runtime_root and source_file.suffix.lower() not in (".md", ".txt"):
                continue
            if looks_like_absolute_symlink(source_file):
                continue
            if should_skip_packaged_relpath(
                relpath,
                is_dir=False,
            ):
                continue
            if should_skip_skill_reference_document(display_path) or display_path in seen:
                continue

            text, _encoding = read_text(source_file)
            if text is None or not text.strip():
                continue
            discovered.append(_build_document_entry(display_path, source_file, text))
            seen.add(display_path)

    return discovered


def _iter_profile_fixed_instruction_documents(
    *,
    runtime_dir: Optional[str] = None,
    target=None,
) -> list[SourceDocument]:
    profile = getattr(target, "profile", None)
    if not isinstance(profile, dict):
        return []
    documents: list[SourceDocument] = []
    for file_spec in profile.get("fixed_scan_files", []):
        if not isinstance(file_spec, dict):
            continue
        display_path = str(file_spec.get("display_path", "") or "").strip().strip("/")
        if not display_path or not is_instruction_doc(display_path):
            continue
        if should_skip_skill_reference_document(display_path):
            continue
        source_file = call_optional_target_hook(
            target,
            "resolve_fixed_scan_file",
            file_spec,
            runtime_dir=runtime_dir,
            default=None,
        )
        if source_file is None:
            source_file = resolve_path_spec(file_spec, runtime_dir=runtime_dir)
        source_file = Path(source_file).expanduser()
        if not source_file.is_file():
            continue
        text, _encoding = read_text(source_file)
        if text is None or not text.strip():
            continue
        documents.append(_build_document_entry(display_path, source_file, text))
    return documents


def _append_unique_document(
    documents: list[SourceDocument],
    seen: set[str],
    document: SourceDocument,
) -> None:
    path = str(document.get("path", "")).strip()
    if not path or path in seen:
        return
    seen.add(path)
    documents.append(document)


def discover_documents(
    stage_plan: StagePlan,
    *,
    runtime_dir: Optional[str] = None,
    target=None,
) -> list[SourceDocument]:
    documents: list[SourceDocument] = []
    seen: set[str] = set()
    runtime_root = Path(runtime_dir).expanduser().resolve(strict=False) if runtime_dir else None

    for tree_source in stage_plan.tree_sources:
        for document in _iter_tree_source_documents(tree_source, runtime_root=runtime_root, target=target):
            _append_unique_document(documents, seen, document)

    for document in _iter_profile_fixed_instruction_documents(runtime_dir=runtime_dir, target=target):
        _append_unique_document(documents, seen, document)

    for file_source in stage_plan.file_sources:
        source_file = file_source.source_file.expanduser()
        if file_source.scan_only:
            display_path = file_source.source_key.strip()
        else:
            assert file_source.relative_target_path is not None
            display_path = file_source.relative_target_path.as_posix()
        if not source_file.is_file():
            continue
        if should_skip_skill_reference_document(display_path) or display_path in seen:
            continue
        text, _encoding = read_text(source_file)
        if text is None or not text.strip():
            continue
        _append_unique_document(documents, seen, _build_document_entry(display_path, source_file, text))

    documents.sort(key=lambda item: str(item.get("path", "")))
    return documents


__all__ = [
    "discover_documents",
]
