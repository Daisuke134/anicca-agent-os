from __future__ import annotations

from pathlib import PurePosixPath
from typing import List, Optional, TypedDict

from .selectable import is_absolute_like_path, normalize_text


SELECTION_GROUP_KEYS = (
    "skills",
    "workspace_documents",
)
RUNTIME_SELECTION_GROUP_KEYS = (
    "skills",
)
_DEFAULT_SELECTION = "selected"







class GroupItem(TypedDict, total=False):
    path: str
    selection: str
    purpose: str
    requires_user_confirmation: bool
    name: str
    description: str
    decision: str
    origin: str
    source_path: str
    source_root: str
    source_kind: str
    binding_kind: str
    config_ref: str
    skill_key: str
    synopsis: str
    reasons: List[str]


class SelectionGroups(TypedDict, total=False):
    skills: List[GroupItem]
    workspace_documents: List[GroupItem]







def is_selected_selection_group_item(item: object) -> bool:
    if not isinstance(item, dict):
        return False
    selection = normalize_text(item.get("selection")).lower()
    return selection == _DEFAULT_SELECTION


def _purpose_from_reasons(reasons: object) -> str:
    if not isinstance(reasons, list):
        return ""
    for item in reasons:
        normalized = normalize_text(item)
        if normalized:
            return normalized
    return ""


def _explicit_purpose(item: dict) -> str:
    explicit = normalize_text(item.get("purpose"))
    if explicit:
        return explicit
    return _purpose_from_reasons(item.get("reasons"))


def _document_purpose(path: str) -> str:
    filename = PurePosixPath(path).name.lower()
    if filename == "claude.md":
        return "Usually contains private project instructions and local context"
    if filename == "agents.md":
        return "Workflow instructions and behavioral constraints"
    if filename == "soul.md":
        return "Persona definition and long-term behavioral constraints"
    if filename == "tools.md":
        return "Tool instructions and invocation context"
    if filename == "user.md":
        return "User background and preference context"
    if filename == "heartbeat.md":
        return "Runtime state and recurring task notes"
    if filename == "memory.md" or "/memory/" in f"/{path.lower()}":
        return "Memory context and accumulated reference material"
    return "Workspace document context"


def _unit_purpose(item: dict) -> str:
    explicit = _explicit_purpose(item)
    if explicit:
        return explicit
    return "Workflow execution unit"







def _base_group_item(
    item: dict,
    *,
    purpose: str,
) -> GroupItem:
    payload: GroupItem = {
        "path": normalize_text(item.get("path")),
        "selection": _DEFAULT_SELECTION,
        "purpose": normalize_text(purpose) or "Purpose pending confirmation",
        "requires_user_confirmation": True,
    }
    for key in (
        "name",
        "description",
        "decision",
        "origin",
        "source_path",
        "source_root",
        "source_kind",
        "binding_kind",
        "config_ref",
        "skill_key",
        "synopsis",
    ):
        value = item.get(key)
        normalized = normalize_text(value)
        if normalized:
            payload[key] = normalized  # type: ignore[literal-required]
    reasons = item.get("reasons")
    if isinstance(reasons, list):
        normalized_reasons = [normalize_text(reason) for reason in reasons if normalize_text(reason)]
        if normalized_reasons:
            payload["reasons"] = normalized_reasons
    return payload







def _group_selected_units(
    selected_units: list,
) -> dict:
    grouped: dict = {
        "skills": [],
    }
    for item in selected_units:
        selection = normalize_text(item.get("selection")).lower()
        if selection and selection != _DEFAULT_SELECTION:
            continue
        path = normalize_text(item.get("path"))
        if not path:
            continue
        if is_absolute_like_path(path):
            raise ValueError("selected_units item path must be a logical path, not an absolute path")
        grouped["skills"].append(
            _base_group_item(
                item,
                purpose=_unit_purpose(item),
            )
        )
    return grouped


def build_selected_selection_groups(
    *,
    selected_units: Optional[list] = None,
    context_sources_input: Optional[dict] = None,
) -> SelectionGroups:
    if selected_units is None:
        normalized_selected_units: list = []
    else:
        if not isinstance(selected_units, list):
            raise ValueError("selected_units must be an array")
        for item in selected_units:
            if not isinstance(item, dict):
                raise ValueError("selected_units items must be objects")
        normalized_selected_units = selected_units
    groups: SelectionGroups = {key: [] for key in SELECTION_GROUP_KEYS}  # type: ignore[misc]
    groups.update(  # type: ignore[typeddict-item]
        _group_selected_units(normalized_selected_units)
    )

    if context_sources_input is None:
        candidates: dict = {}
    else:
        if not isinstance(context_sources_input, dict):
            raise ValueError("context_sources_input must be an object")
        candidates = context_sources_input
    if "workspace_documents" in candidates and not isinstance(candidates.get("workspace_documents"), list):
        raise ValueError("workspace_documents must be an array")
    for item in candidates.get("workspace_documents", []):
        if not isinstance(item, dict):
            raise ValueError("workspace_documents items must be objects")
    for item in candidates.get("workspace_documents", []):
        path = normalize_text(item.get("path"))
        if not path:
            continue
        selection = normalize_text(item.get("selection")).lower()
        if selection and selection != _DEFAULT_SELECTION:
            continue
        groups["workspace_documents"].append(
            _base_group_item(
                item,
                purpose=_explicit_purpose(item) or _document_purpose(path),
            )
        )
    return groups


def normalize_documented_selection_groups(raw: object) -> SelectionGroups:
    groups: SelectionGroups = {key: [] for key in SELECTION_GROUP_KEYS}  # type: ignore[misc]
    if not isinstance(raw, dict):
        return groups
    for key in SELECTION_GROUP_KEYS:
        value = raw.get(key, [])
        if not isinstance(value, list):
            continue
        items: list = []
        for item in value:
            if not isinstance(item, dict):
                continue
            path = normalize_text(item.get("path"))
            if not path:
                continue
            normalized = dict(item)
            normalized.pop("confidence", None)
            normalized.pop("unit_type", None)
            normalized["path"] = path
            normalized["purpose"] = normalize_text(item.get("purpose")) or "Purpose pending confirmation"
            normalized["requires_user_confirmation"] = bool(item.get("requires_user_confirmation"))
            selection = normalize_text(item.get("selection")) or _DEFAULT_SELECTION
            normalized["selection"] = selection
            items.append(normalized)
        groups[key] = items  # type: ignore[literal-required]
    return groups


def strip_default_selection_fields(groups: SelectionGroups) -> SelectionGroups:
    stripped_groups: SelectionGroups = {key: [] for key in SELECTION_GROUP_KEYS}  # type: ignore[misc]
    for key in SELECTION_GROUP_KEYS:
        for item in groups.get(key, []):  # type: ignore[literal-required]
            normalized = dict(item)
            if normalize_text(normalized.get("selection")).lower() == _DEFAULT_SELECTION:
                normalized.pop("selection", None)
            stripped_groups[key].append(normalized)  # type: ignore[literal-required]
    return stripped_groups


def selected_items_for_group(groups: SelectionGroups, key: str) -> list:
    return [
        item
        for item in groups.get(key, [])  # type: ignore[literal-required]
        if is_selected_selection_group_item(item)
    ]


__all__ = [
    "RUNTIME_SELECTION_GROUP_KEYS",
    "SELECTION_GROUP_KEYS",
    "GroupItem",
    "SelectionGroups",
    "build_selected_selection_groups",
    "is_selected_selection_group_item",
    "normalize_documented_selection_groups",
    "selected_items_for_group",
    "strip_default_selection_fields",
]
